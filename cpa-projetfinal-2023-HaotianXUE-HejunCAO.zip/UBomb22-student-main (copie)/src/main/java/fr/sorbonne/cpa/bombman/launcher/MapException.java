package fr.sorbonne.cpa.bombman.launcher;

public class MapException extends RuntimeException {
    public MapException(String message) {
        super(message);
    }
}
